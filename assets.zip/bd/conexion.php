<?php

$usuario = "sycchile_user";
$clave = "[=.)BA$,4Z4s";
$db_nombre = "sycchile_sesion";
$host = "localhost";

try {
   $conn = new PDO("mysql:host=$host;dbname=$db_nombre", $usuario, $clave);
} catch (PDOException $e) {
    echo "error base de datos no encontrada";
}

?>