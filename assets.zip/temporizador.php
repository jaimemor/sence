<?php
header('P3P: CP="CAO PSA OUR"');
session_start();
include 'variables.php';
$tipo=2;
if (empty($_SESSION['CodSence'])) {
    
}else{
  if (isset($_GET['horas']) || isset($_GET['tipo'])) {
    
    if ($_GET['tipo'] == 0) {
      $horas = $_GET['horas'];
      $tipo= $_GET['tipo'];
    }elseif ($_GET['tipo'] == 1) {
      $tipo= $_GET['tipo'];
    }else{
      
    }
  }else{
    
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>sycchileconsultores.cl</title>


 <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
</head>

  <?php if ($tipo == 0): ?>
    <body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="text-center">Sence</h1>
        <p id="demo" class="h1 text-center "></p>
    <audio id="audio" loop>
  <source src="horse.mp3" type="audio/mp3">
  </audio>
        <form class="text-center" action="<?php echo $urlCe;?>" method="post" target="_blank">

  <p><input type="hidden"  name="RutOtec" value="<?php echo $RutOtecV;?>"></p>
  <p><input type="hidden"  name="Token" value="<?php echo $TokenV;?>"></p>
  <p><input type="hidden"  name="CodSence" value="<?php echo $_SESSION['CodSence'];?>"></p>
  <p><input type="hidden"  name="CodigoCurso" value="<?php echo $_SESSION['CodigoCurso'];?>"></p>
  <p><input type="hidden"  name="LineaCapacitacion" value="<?php echo $_SESSION['LineaCapacitacion'];?>"></p>
  <p><input type="hidden"  name="RunAlumno"  value="<?php echo $_SESSION['RunAlumno'];?>"></p>
  <p><input type="hidden" name="IdSesionAlumno" value="<?php echo $_SESSION['IdSesionAlumno'];?>"></p>
  <p><input type="hidden"  name="IdSesionSence" value="<?php echo $_SESSION['IdSesionSence'];?>"></p>
  <p><input type="hidden"  name="UrlRetoma" value="<?php echo $UrlCierreV;?>"></p>
  <p><input type="hidden" name="UrlError" value="<?php echo $UrlCierreV;?>"></p>

  
  <button type="submit" class="btn btn-danger ">Cerrar Sesión</button>
</form>
        
      </div>
    </div>
  </div>


<script>
var hora_inicio_sesion = "<?php echo $_SESSION['FechaHora'];?>"
var countDownDate = new Date(hora_inicio_sesion).getTime();
var nuevo = countDownDate + (3600000*<?php echo $horas;?>);

var x = setInterval(function() {

  var y = document.getElementById("audio");
  var now = new Date().getTime();
  var distance = nuevo - now;
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  
  function audio(){
  y.play();
  }
  function pause(){
  y.pause();
  }
  if ((minutes == 10) && (seconds < 5)){
  audio();
  }else{
  pause();
  }
  document.getElementById("demo").innerHTML =hours+"h "+ minutes + "m";
  
  if (distance < 0) {
  clearInterval(x);
  document.getElementById("demo").innerHTML = "Tiempo Terminado";
  }
}, 1000)
</script>

<? elseif ($tipo == 1): ?>
  <body onload="empezarDetener(this);">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="text-center">Sence</h1>
        <div class="crono_wrapper">
        <h2 id='crono'class="text-center" >00:00:00</h2>
        </div>
   
        <form class="text-center" action="<?php echo $urlCe;?>" method="post" target="_blank">

  <p><input type="hidden"  name="RutOtec" value="<?php echo $RutOtecV;?>"></p>
  <p><input type="hidden"  name="Token" value="<?php echo $TokenV;?>"></p>
  <p><input type="hidden"  name="CodSence" value="<?php echo $_SESSION['CodSence'];?>"></p>
  <p><input type="hidden"  name="CodigoCurso" value="<?php echo $_SESSION['CodigoCurso'];?>"></p>
  <p><input type="hidden"  name="LineaCapacitacion" value="<?php echo $_SESSION['LineaCapacitacion'];?>"></p>
  <p><input type="hidden"  name="RunAlumno"  value="<?php echo $_SESSION['RunAlumno'];?>"></p>
  <p><input type="hidden" name="IdSesionAlumno" value="<?php echo $_SESSION['IdSesionAlumno'];?>"></p>
  <p><input type="hidden"  name="IdSesionSence" value="<?php echo $_SESSION['IdSesionSence'];?>"></p>
  <p><input type="hidden"  name="UrlRetoma" value="<?php echo $UrlCierreV;?>"></p>
  <p><input type="hidden" name="UrlError" value="<?php echo $UrlCierreV;?>"></p>

  
  <button type="submit" class="btn btn-danger ">Cerrar Sesión</button>
</form>
        
      </div>
    </div>
  </div>

<script>
  var inicio=0;
  var timeout=0;
 
  function empezarDetener(elemento)
  {
    if(timeout==0)
    {
      // empezar el cronometro
 
      elemento.value="Detener";
 
      // Obtenemos el valor actual
      inicio=vuelta=new Date().getTime();
 
      // iniciamos el proceso
      funcionando();
    }else{
      // detemer el cronometro
 
      elemento.value="Empezar";
      clearTimeout(timeout);
      timeout=0;
    }
  }
 
  function funcionando()
  {
    // obteneos la fecha actual
    var fecha_inicio_session= "<?php echo $_SESSION['FechaHora'];?>"
    var actual = new Date().getTime();
 
    // obtenemos la diferencia entre la fecha actual y la de inicio
    var nuevo=new Date(fecha_inicio_session);
    var diff=new Date(actual-nuevo);
 
    // mostramos la diferencia entre la fecha actual y la inicial
    var result=LeadingZero(diff.getUTCHours())+":"+LeadingZero(diff.getUTCMinutes())+":"+LeadingZero(diff.getUTCSeconds());
    document.getElementById('crono').innerHTML = result;
 
    // Indicamos que se ejecute esta función nuevamente dentro de 1 segundo
    timeout=setTimeout("funcionando()",1000);
  }
 
  /* Funcion que pone un 0 delante de un valor si es necesario */
  function LeadingZero(Time) {
    return (Time < 10) ? "0" + Time : + Time;
  }
  </script>






  <!-- Bootstrap core JavaScript -->
  <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/web/assets/jquery/jquery.min.js"></script>
 

<? else: ?>
  <body>
    <div class="container">
    <div class="row">
      <div class="col-md-12">
  <form class="text-center" action="<?php echo $urlCe;?>" method="post" target="_blank">

  <p><input type="hidden"  name="RutOtec" value="<?php echo $RutOtecV;?>"></p>
  <p><input type="hidden"  name="Token" value="<?php echo $TokenV;?>"></p>
  <p><input type="hidden"  name="CodSence" value="<?php echo $_SESSION['CodSence'];?>"></p>
  <p><input type="hidden"  name="CodigoCurso" value="<?php echo $_SESSION['CodigoCurso'];?>"></p>
  <p><input type="hidden"  name="LineaCapacitacion" value="<?php echo $_SESSION['LineaCapacitacion'];?>"></p>
  <p><input type="hidden"  name="RunAlumno"  value="<?php echo $_SESSION['RunAlumno'];?>"></p>
  <p><input type="hidden" name="IdSesionAlumno" value="<?php echo $_SESSION['IdSesionAlumno'];?>"></p>
  <p><input type="hidden"  name="IdSesionSence" value="<?php echo $_SESSION['IdSesionSence'];?>"></p>
  <p><input type="hidden"  name="UrlRetoma" value="<?php echo $UrlCierreV;?>"></p>
  <p><input type="hidden" name="UrlError" value="<?php echo $UrlCierreV;?>"></p>

  
  <button type="submit" class="btn btn-danger ">Cerrar Sesión</button>
</form>
</div>
    </div>
  </div>
<? endif; ?>




</body>
</html>