<?php
session_start();
if (empty($_REQUEST['GlosaError'])) {
	if (!empty($_REQUEST['CodSence'])) {
	
	$_SESSION['CodSence'] = $_REQUEST['CodSence'];
	$_SESSION['IdSesionAlumno'] = $_REQUEST['IdSesionAlumno'];
	$_SESSION['LineaCapacitacion'] = $_REQUEST['LineaCapacitacion'];
	$_SESSION['CodigoCurso']= $_REQUEST['CodigoCurso'];
	$_SESSION['RunAlumno'] = $_REQUEST['RunAlumno'];
	$_SESSION['FechaHora']= $_REQUEST['FechaHora'];
	$_SESSION['ZonaHoraria'] = $_REQUEST['ZonaHoraria'];
	$_SESSION['IdSesionSence']= $_REQUEST['IdSesionSence'];
	header("Location:validado.php");
}else{
	echo "-------";
	echo$_SESSION['IdSesionSence'];
	echo "-------";
	echo $_SESSION['FechaHora'];
	echo "-------";
	echo $_SESSION['CodSence'];
	echo "-------";
	echo $_SESSION['CodigoCurso'];
}
}else{
	session_destroy();
	header("Location:error.php?GlosaError=".$_REQUEST['GlosaError']);
}

?>