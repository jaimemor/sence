<?php
include 'variables.php';
  if (!empty($_GET['CodSence']) && !empty($_GET['CodigoCurso'])){
    $CodSence = $_GET['CodSence'];
    $CodigoCurso = $_GET['CodigoCurso'];
  }else{
  header("Location: index.php");}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>sycchileconsultores.cl</title>


  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="text-center">Sence</h1>
        <form class="text-center" action="<?php echo $urlIN; ?>" method="post" target="_blank">
  <div class="form-group ">
    <label for="Rut">Rut</label>
    <input type="text" class="form-control" id="Rut" aria-describedby="emailHelp" placeholder="" name="RunAlumno" autofocus autocomplete="off"  minlength="9" maxlength="10"  pattern="\d{3,8}-[\d|kK]{1}">
    <small id="emailHelp" class="form-text text-muted">Ingresar rut con guion y sin puntos.</small>
  </div>
  <div class="form-group">
    <label for="IdSesionAlumno">ID Alumno</label>
    <input type="text" class="form-control" id="IdSesionAlumno" placeholder="" name="IdSesionAlumno" required autofocus autocomplete="off"  minlength="8" maxlength="9" pattern="[0-9]{8,11}" >
    <small  class="form-text text-muted">Ingresar rut sin guion ni puntos.</small>
  </div>

<p><input type="hidden" name="RutOtec" value="<?php echo $RutOtecV;?>"></p>
  <p><input type="hidden"  name="Token" value="<?php echo $TokenV;?>"></p>
  <p><input type="hidden"  name="CodSence" value="<?php echo $CodSence;?>"></p>
  <p><input type="hidden"  name="CodigoCurso" value="<?php echo $CodigoCurso;?>"></p>
  <p><input type="hidden"  name="LineaCapacitacion" value="<?php echo $LineaCapacitacionV ; ?>"></p>
  <p><input type="hidden"  name="UrlRetoma" value="<?php echo $UrlRetomaV;?>"></p>
    <p><input type="hidden"  name="UrlError" value="<?php echo $UrlErrorV;?>"></p>
  <button type="submit" class="btn btn-primary ">Iniciar Sesión</button>
</form>
      </div>
    </div>
  </div>


  

  <!-- Bootstrap core JavaScript -->
  <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/web/assets/jquery/jquery.min.js"></script>
</body>
</html>