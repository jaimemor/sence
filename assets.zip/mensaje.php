<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	 <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body style="background: #efefef;">
		<div class="container" >
			<div class="row">
				<div class="col-md-12">
					<img src="assets/images/Imagotipo.jpg" class="rounded mx-auto d-block" alt="" width="250" height="170">
				</div>
			</div>
		</div>

		  <!-- Bootstrap core JavaScript -->
  <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/web/assets/jquery/jquery.min.js"></script>
</body>
</html>