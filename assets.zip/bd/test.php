<?php 
include "insertar.php";
include "select.php";
include "eliminar.php";
 

$parti = new insertar();
$parti->in_participante(34234234,"diego","hola","hola","hola","hola");

$sel = new Select();
$resultado = $sel->buscasesion(4);

if (isset($resultado[0])){
	print_r ($resultado);
}


$eli = new Eliminar();
$eli->eliminarsesion(1,"hola");


?>