<?php 

/**
 * 
 */
class Select 
{
	
	function buscasesion($rut)
	{
		require "conexion.php";
		$sql ="select * from participante WHERE IdSesionAlumno = $rut";
        $smt=$conn->prepare($sql);
        $smt->execute();
        $resultado= $smt->fetchall();
        $conn=null;

        return $resultado;
		
	}
}



?>